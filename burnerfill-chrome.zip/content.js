(() => {
  if (window.__tempAutofillLoaded) return;
  window.__tempAutofillLoaded = true;

  const SIGNUP_SCORE_THRESHOLD = 3;
  let credentials = null;        // {address, password}
  let generateRequested = false; // one generation per page load
  let otpPollStarted = false;    // one poll start per OTP page
  let otpFilled = false;

  // ================= debug log =================
  // Sent to the background, which stores it for the popup's Debug tab.
  function dlog(msg, data) {
    console.log("[BurnerFill:page]", msg, data ?? "");
    try {
      chrome.runtime.sendMessage({ type: "LOG", msg, data }, () => void chrome.runtime.lastError);
    } catch { /* extension reloaded under us */ }
  }

  // short, readable description of an input, e.g. input[text name=email ph="Enter email"]
  function describe(el) {
    if (!el) return null;
    const bits = [el.type || "text"];
    if (el.name) bits.push(`name=${el.name}`);
    if (el.id) bits.push(`id=${el.id}`);
    if (el.placeholder) bits.push(`ph="${el.placeholder}"`);
    if (el.autocomplete) bits.push(`ac=${el.autocomplete}`);
    if (el.maxLength > 0) bits.push(`max=${el.maxLength}`);
    return `input[${bits.join(" ")}]`;
  }

  const EMAIL_RE = /[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g;

  // ================= settings helpers =================
  const DEFAULTS = {
    autoGenerate: true, fillEmail: true, fillPassword: true,
    fillConfirmPassword: true, autoSubmitOtp: false, apiToken: "",
  };
  let settings = { ...DEFAULTS };

  // popup power button: storage "enabled" === false means hands off the page entirely
  let enabled = true;

  async function loadSettings() {
    try {
      const { settings: s, enabled: on } = await new Promise((res) =>
        chrome.storage.local.get(["settings", "enabled"], res)
      );
      settings = { ...DEFAULTS, ...(s || {}) };
      enabled = on !== false;
    } catch { /* keep defaults */ }
  }

  // flip immediately when the popup turns us off/on - no page reload needed
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.enabled) return;
    enabled = changes.enabled.newValue !== false;
    if (enabled) scan();
  });

  // ================= toast UI =================
  function toast(message, kind = "info") {
    const colors = {
      info: "#2563eb", success: "#16a34a", error: "#dc2626", warning: "#d97706",
    };
    const el = document.createElement("div");
    el.textContent = message;
    Object.assign(el.style, {
      position: "fixed", bottom: "20px", right: "20px", zIndex: "2147483647",
      background: colors[kind] || colors.info, color: "#fff", padding: "10px 16px",
      borderRadius: "8px", font: "13px/1.4 system-ui, sans-serif", maxWidth: "340px",
      boxShadow: "0 4px 12px rgba(0,0,0,.25)", transition: "opacity .4s", opacity: "1",
    });
    document.body.appendChild(el);
    setTimeout(() => { el.style.opacity = "0"; }, 4200);
    setTimeout(() => el.remove(), 4800);
  }

  // ================= value setting (React/Vue safe) =================
  function setNativeValue(el, value) {
    if (el.isContentEditable) {
      el.focus();
      el.textContent = value;
      el.dispatchEvent(new InputEvent("input", { bubbles: true }));
      return;
    }
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // ================= field detection =================
  function fieldLabelContext(el) {
    // look at nearby text for context (label, wrapper, previous siblings)
    let node = el.closest("label, div, p, td, li") || el.parentElement;
    let text = "";
    for (let i = 0; i < 3 && node; i++) {
      text += " " + (node.textContent || "");
      node = node.parentElement;
    }
    return text.toLowerCase().slice(0, 300);
  }

  function fieldAttrText(el) {
    return [
      el.name, el.id, el.placeholder, el.autocomplete,
      el.getAttribute("aria-label"), el.className,
    ].filter(Boolean).join(" ").toLowerCase();
  }

  function isPasswordConfirm(el) {
    const t = fieldAttrText(el) + " " + fieldLabelContext(el);
    return /confirm|repeat|re-?enter|retype|again|match/.test(t);
  }

  function findEmailField(includeFilled = false) {
    return (
      document.querySelector('input[type="email"]') ||
      [...document.querySelectorAll('input[type="text"], input:not([type])')].find(
        (el) => /e[-_]?mail/.test(fieldAttrText(el)) && (includeFilled || !el.value) && el.offsetParent !== null
      ) || null
    );
  }

  function findPasswordFields() {
    const pwds = [...document.querySelectorAll('input[type="password"]')].filter(
      (el) => el.offsetParent !== null
    );
    if (pwds.length === 0) return { password: null, confirm: null };
    if (pwds.length === 1) return { password: pwds[0], confirm: null };
    // 2+: pick confirm by label, else 2nd is confirm
    const confirm = pwds.find((el, i) => i > 0 && isPasswordConfirm(el)) || pwds[1];
    const password = pwds.find((el) => el !== confirm && !isPasswordConfirm(el)) || pwds[0];
    return { password, confirm };
  }

  function findSignupForm() {
    // narrow scope to the form that holds the most password fields, if any
    const pwds = document.querySelectorAll('input[type="password"]');
    if (!pwds.length) return document;
    const form = pwds[0].closest("form");
    return form || document;
  }

  function scoreSignup() {
    const url = location.href.toLowerCase();
    let score = 0;
    if (/signup|sign-up|sign_up|register|registration|\bjoin\b|create[-_]?account/.test(url)) score += 3;

    const pwds = [...document.querySelectorAll('input[type="password"]')].filter((el) => el.offsetParent !== null);
    if (pwds.length >= 2) score += 3;
    else if (pwds.length === 1) score += 1;

    if (findEmailField()) score += 1;

    const form = findSignupForm();
    const text = (form.innerText || "").toLowerCase().slice(0, 4000);
    if (/sign\s?up|create (an\s)?account|register|get started/.test(text)) score += 1;
    if (/forgot (your\s)?password|remember me|log\s?in to your/.test(text)) score -= 3;

    return score;
  }

  function looksLikeSignup() {
    return scoreSignup() >= SIGNUP_SCORE_THRESHOLD;
  }

  // ============ OTP detection ============
  function findOtpFields() {
    // single OTP input
    const all = [...document.querySelectorAll('input')].filter((el) => el.offsetParent !== null);
    const single = all.find((el) => {
      const t = fieldAttrText(el);
      return (
        el.autocomplete === "one-time-code" ||
        (/(otp|one.?time|verif|verification|security code|digit code|\bpin\b|\bcode\b)/.test(t) &&
          !/promo|coupon|voucher|referr|invite|discount|gift|zip|postal|area|country/.test(t) &&
          (el.type === "text" || el.type === "tel" || el.type === "number"))
      );
    });
    if (single) return { type: "single", input: single };

    // multiple single-char boxes
    const boxes = all.filter((el) =>
      el.maxLength === 1 && ["text", "tel", "number"].includes(el.type)
    );
    if (boxes.length >= 4) {
      // confirm they're grouped (common parent within reasonable distance)
      const scope = boxes[0].closest("form, div, section") || document;
      const grouped = boxes.filter((b) => scope.contains(b));
      if (grouped.length >= 4) return { type: "multi", inputs: grouped };
    }
    return null;
  }

  function looksLikeOtpPage() {
    if (document.querySelector('input[autocomplete="one-time-code"]')) return true;
    if (looksLikeSignup()) return false;
    if (/otp|verify|verification|confirm.{0,10}(email|code)/i.test(location.href)) return true;
    const f = findOtpFields();
    return !!f && f.type === "multi"; // multi-box almost certainly OTP
  }

  // ================= filling =================
  // overwrite: replace values already in the fields (used when the popup regenerates)
  function fillCredentials(overwrite = false) {
    const filled = [];
    if (!credentials) return filled;
    const canFill = (el) => el && (overwrite || !el.value);

    if (settings.fillEmail) {
      const emailEl = findEmailField(overwrite);
      if (canFill(emailEl)) {
        setNativeValue(emailEl, credentials.address);
        filled.push("email");
      }
    }

    if (settings.fillPassword) {
      const { password, confirm } = findPasswordFields();
      if (canFill(password)) {
        setNativeValue(password, credentials.password);
        filled.push("password");
      }
      if (settings.fillConfirmPassword && canFill(confirm)) {
        setNativeValue(confirm, credentials.password);
        filled.push("confirm");
      }
    }

    if (filled.length) {
      toast(`✔ Filled: ${filled.join(", ")}`, "success");
      const emailEl = settings.fillEmail ? findEmailField(true) : null;
      dlog(`filled ${filled.join(", ")}` + (overwrite ? " (overwrite)" : ""), {
        address: credentials.address, emailField: describe(emailEl),
      });
      // frameworks sometimes reset a value they didn't set themselves
      setTimeout(() => {
        if (emailEl && filled.includes("email") && emailEl.value !== credentials.address) {
          dlog("WARNING email field changed after fill", { expected: credentials.address, now: emailEl.value });
        }
      }, 1500);
    }
    return filled;
  }

  function fillOtp(otp, copied = false) {
    const f = findOtpFields();
    if (!f) return false;
    if (f.type === "single") {
      setNativeValue(f.input, otp);
    } else {
      f.inputs.forEach((inp, i) => {
        if (otp[i]) setNativeValue(inp, otp[i]);
      });
    }
    otpFilled = true;
    toast(`✔ OTP filled: ${otp}` + (copied ? " · also copied" : ""), "success");
    dlog(`OTP filled into ${f.type === "single" ? describe(f.input) : f.inputs.length + " boxes"}`, { otp });

    if (settings.autoSubmitOtp) {
      setTimeout(() => {
        const btn =
          f.input.closest("form")?.querySelector('button[type="submit"]') ||
          [...document.querySelectorAll("button")].pop();
        btn?.click();
      }, 300);
    }
    return true;
  }

  // ================= main scan loop =================
  let lastScanState = "";
  let lastPageEmails = "";

  // only pages we act on get logged - not every site the content script runs on
  const relevant = () => enabled && (!!credentials || scoreSignup() >= SIGNUP_SCORE_THRESHOLD || !!findOtpFields());

  function logScanState() {
    if (!relevant()) return;
    const otp = findOtpFields();
    const { password, confirm } = findPasswordFields();
    const state = {
      url: location.pathname + location.search.slice(0, 60),
      frame: window === top ? "top" : "iframe",
      signupScore: scoreSignup(),
      emailField: describe(findEmailField(true)),
      passwordFields: [password, confirm].filter(Boolean).length,
      otpField: otp ? (otp.type === "single" ? describe(otp.input) : `${otp.inputs.length} boxes`) : null,
      looksLikeOtpPage: looksLikeOtpPage(),
      haveCredentials: credentials?.address || null,
    };
    const key = JSON.stringify(state);
    if (key !== lastScanState) {
      lastScanState = key;
      dlog("page state", state);
    }

    // addresses the page itself mentions - e.g. Xiaomi's "Sent code to x@y"
    const mentioned = [...new Set((document.body?.innerText || "").match(EMAIL_RE) || [])].slice(0, 5);
    const mkey = mentioned.join(",");
    if (mkey && mkey !== lastPageEmails) {
      lastPageEmails = mkey;
      dlog("page text mentions", {
        addresses: mentioned,
        matchesOurs: credentials ? mentioned.includes(credentials.address) : "no credentials yet",
      });
    }
  }

  async function scan() {
    await loadSettings();
    if (!enabled) return; // switched off from the popup: no detection, fills or logs
    logScanState();

    // an OTP field on screen: the code may already be sitting on the session,
    // since polling now starts as soon as the inbox is created
    if (!otpFilled && findOtpFields()) {
      chrome.runtime.sendMessage({ type: "GET_SESSION" }, (res) => {
        if (chrome.runtime.lastError) return;
        if (res?.session?.otp && !otpFilled) {
          dlog("OTP already on session, filling", { otp: res.session.otp });
          fillOtp(res.session.otp);
        }
      });

      if (!otpPollStarted) {
        otpPollStarted = true;
        chrome.runtime.sendMessage({ type: "POLL_START", url: location.href }, (res) => {
          if (chrome.runtime.lastError) return;
          if (res?.ok) toast("⏳ Waiting for OTP email…", "info");
        });
      }

      if (looksLikeOtpPage()) return; // dedicated OTP page, not a signup form
    }

    // signup page?
    if (looksLikeSignup() && !generateRequested && settings.autoGenerate) {
      const emailEl = findEmailField();
      if (emailEl && !emailEl.value) {
        generateRequested = true;
        dlog("signup detected, asking for inbox", { emailField: describe(emailEl) });
        chrome.runtime.sendMessage({ type: "GENERATE", url: location.href }, (res) => {
          if (chrome.runtime.lastError) return;
          dlog("GENERATE reply", res);
          if (!res?.ok) {
            toast(`Temp email failed: ${res?.error || "unknown"}`, "error");
            generateRequested = false; // allow retry on next scan
            return;
          }
          credentials = { address: res.address, password: res.password };
          if (res.reused) toast("♻ Reusing session for this page", "info");
          else toast(`✉ Generated: ${res.address} (password saved)`, "success");
          fillCredentials();
        });
      }
    } else if (credentials) {
      // multi-step forms: fill newly appeared empty fields
      fillCredentials();
    }
  }

  // ================= right-click fill =================
  // the menu click arrives in the background; remember which field it was for.
  // composedPath() reaches inputs inside shadow DOM, where e.target is the host
  let lastContextTarget = null;
  document.addEventListener("contextmenu", (e) => {
    lastContextTarget = e.composedPath?.()[0] || e.target;
  }, true);

  const FIELD_LABEL = { email: "temp email", password: "password", otp: "OTP code" };

  function fillFromMenu(msg) {
    const target = (lastContextTarget?.isConnected && lastContextTarget) || document.activeElement;
    const fillable = target && (target.matches?.("input, textarea") || target.isContentEditable);
    if (!fillable) {
      toast("Right-click inside a text field to fill it", "warning");
      return false;
    }

    credentials = { address: msg.address, password: msg.password };
    generateRequested = true; // keep auto-generate from swapping the inbox now

    const group = msg.kind === "otp" ? findOtpFields() : null;
    if (group?.type === "multi" && group.inputs.includes(target)) {
      group.inputs.forEach((inp, i) => { if (msg.value[i]) setNativeValue(inp, msg.value[i]); });
    } else {
      setNativeValue(target, msg.value);
    }
    if (msg.kind === "otp") otpFilled = true;

    toast(`✔ Filled ${FIELD_LABEL[msg.kind]}`, "success");
    dlog(`right-click filled ${msg.kind}`, { field: describe(target) });
    return true;
  }

  // ================= listeners =================
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "FILL_FIELD") {
      sendResponse({ ok: fillFromMenu(msg) });
    }
    if (msg.type === "TOAST") {
      toast(msg.text, msg.level);
      sendResponse({ ok: true });
    }
    if (msg.type === "OTP_FOUND") {
      dlog("OTP_FOUND received", { otp: msg.otp, otpField: describe(findOtpFields()?.input) });
      if (!fillOtp(msg.otp, msg.copied)) {
        dlog("no OTP field on page yet, retrying for 10s");
        // nowhere to put it (yet) - say where the code is
        if (msg.copied) toast(`📋 Code ${msg.otp} copied to clipboard`, "success");
        // fields might not exist yet — retry for a few seconds
        let tries = 0;
        const t = setInterval(() => {
          if (fillOtp(msg.otp, msg.copied) || ++tries > 10) clearInterval(t);
        }, 1000);
      }
      sendResponse({ ok: true });
    }
    if (msg.type === "FILL") {
      dlog("FILL from popup", { address: msg.address });
      credentials = { address: msg.address, password: msg.password };
      generateRequested = true; // keep auto-generate from replacing it
      otpFilled = false;        // new inbox, new code to come
      otpPollStarted = false;
      const filled = fillCredentials(true);
      if (!filled.length) toast(`✉ New email: ${msg.address}`, "info");
      sendResponse({ ok: true, filled });
    }
    if (msg.type === "OTP_TIMEOUT") {
      dlog("OTP_TIMEOUT received");
      toast("OTP email didn't arrive within 12 minutes", "warning");
      sendResponse({ ok: true });
    }
    return true;
  });

  // what the form really holds when it's sent - catches a site keeping its own copy
  document.addEventListener("submit", (e) => {
    if (!relevant()) return;
    const form = e.target;
    const emailEl = form.querySelector?.('input[type="email"]') ||
      [...(form.querySelectorAll?.("input") || [])].find((el) => /e[-_]?mail/.test(fieldAttrText(el)));
    dlog("form submitted", {
      emailFieldValue: emailEl?.value ?? "(no email field in this form)",
      ourAddress: credentials?.address || "(none)",
      match: !!(emailEl && credentials && emailEl.value === credentials.address),
      url: location.pathname,
    });
  }, true);

  // SPA route changes (Xiaomi goes /register -> /register/email/verify without reloading)
  let lastHref = location.href;
  setInterval(() => {
    if (location.href !== lastHref) {
      if (relevant()) dlog("url changed (no reload)", { from: new URL(lastHref).pathname, to: location.pathname });
      lastHref = location.href;
    }
  }, 500);

  // debounce scans when DOM changes (multi-step forms, SPA renders)
  let scanTimer = null;
  const observer = new MutationObserver(() => {
    if (scanTimer) return;
    scanTimer = setTimeout(() => {
      scanTimer = null;
      scan();
    }, 800);
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });

  // initial scans (staggered, in case of slow rendering)
  loadSettings().then(() => {
    scan();
    [1000, 3000, 6000].forEach((d) => setTimeout(scan, d));
  });
})();
