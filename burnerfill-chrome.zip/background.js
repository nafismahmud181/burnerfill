// ================= CONFIG =================
// tempmail.lol API — adjust here if the docs at https://api.tempmail.lol change
const API = {
  v1: {
    create: "https://api.tempmail.lol/generate",
    inbox: (token) => `https://api.tempmail.lol/auth/${token}`,
  },
  v2: {
    create: "https://api.tempmail.lol/v2/inbox",
    inbox: (token) => `https://api.tempmail.lol/v2/inbox?token=${token}`,
  },
};

const SESSION_TTL_MS = 10 * 60 * 1000;      // reuse same email for 10 min after generation
const OTP_POLL_TOTAL_MS = 12 * 60 * 1000;  // keep polling inbox for max 12 minutes
const OTP_ALARM_PERIOD_MIN = 0.5;         // 30s (Chrome 120+ supports sub-minute alarms)
const POLL_MIN_GAP_MS = 4000;             // tempmail.lol answers 429 to inbox checks <3-5s apart
const DEBUG_MAX = 400;                    // debug log entries kept in storage

// ============ debug log ============
// One writer (this worker) so entries from the page and from here never race.
// Readable in the popup's Debug tab, and in this worker's console.
let logChain = Promise.resolve();
function dlog(src, msg, data) {
  const entry = { t: Date.now(), src, msg };
  if (data !== undefined) entry.data = data;
  console.log(`[BurnerFill:${src}]`, msg, data ?? "");
  logChain = logChain.then(async () => {
    const { debugLog } = await chrome.storage.local.get("debugLog");
    const list = debugLog || [];
    list.push(entry);
    if (list.length > DEBUG_MAX) list.splice(0, list.length - DEBUG_MAX);
    await chrome.storage.local.set({ debugLog: list });
  }).catch(() => {});
}
const tok = (t) => (t ? String(t).slice(0, 8) + "…" : "none");

const DEFAULT_SETTINGS = {
  autoGenerate: true,        // auto-generate + fill when a signup page is detected
  fillEmail: true,
  fillPassword: true,
  fillConfirmPassword: true,
  autoSubmitOtp: false,     // auto-click submit after OTP is filled
  autoOpenLink: false,      // open a verification link from the inbox in a new tab
  copyOtp: true,            // put the code on the clipboard when it arrives, like gen_mail.py
  apiToken: "",             // tempmail.lol v2 API token (optional if v1 works)
};

// ============ small utils ============
async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}

// Power button in the popup. A top-level storage key (not inside "settings") so
// Save settings never overwrites it. false = do nothing: no fills, no inbox checks.
async function isEnabled() {
  const { enabled } = await chrome.storage.local.get("enabled");
  return enabled !== false;
}
const OFF_MSG = "BurnerFill is off — turn it on from the popup";

function generatePassword(len = 16) {
  // unambiguous charset (no 0/O/1/l)
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*";
  const arr = crypto.getRandomValues(new Uint32Array(len));
  return Array.from(arr, (n) => chars[n % chars.length]).join("");
}

function stripHtml(html) {
  return html
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&[^;\s]{1,6};/g, " ")
    .replace(/\s+/g, " ");
}

function extractOtp(strings) {
  const text = strings.map((s) => (s || "").toString()).join("\n");
  const patterns = [
    /(?:code|otp|p\.?i\.?n|verif(?:y|ication))[^\d]{0,40}(\d{4,8})/i,
    /\b(\d{6})\b/,
    /(?<!\d ?)(\d(?: \d){5})(?! ?\d)/, // "9 6 7 0 5 2": one digit per cell, tags stripped
  ];
  for (const re of patterns) {
    const m = text.match(re);
    if (m) return m[1].replace(/ /g, "");
  }
  return null;
}

// plain-text body first, like gen_mail.py - HTML mails often render each digit
// in its own cell, which stripHtml turns into "9 6 7 0 5 2"
function otpFromMessage(msg) {
  const body = (msg.body || "").toString();
  const usableBody = body.trim() && !/invalid body|^\s*empty\s*$/i.test(body);
  const sources = [usableBody ? body : "", stripHtml((msg.html || "").toString())];
  for (const text of sources) {
    if (!text.trim()) continue;
    const otp = extractOtp([msg.subject, text]);
    if (otp) return otp;
  }
  return null;
}

function sameSite(a, b) {
  try { return new URL(a).hostname === new URL(b).hostname; } catch { return false; }
}

// ============ tempmail API ============
async function createInbox() {
  const settings = await getSettings();
  const useV2 = !!settings.apiToken;

  try {
    if (useV2) {
      // V2 uses POST
      const res = await fetch(API.v2.create, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-API-Token": settings.apiToken,
          // Add a generic User-Agent to prevent API blocking
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ChromeExtension",
        },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error(`v2 create failed: ${res.status}`);
      const data = await res.json();
      if (!data.address || !data.token) throw new Error("v2 create: missing fields");
      return { address: data.address, token: data.token, apiVersion: "v2" };
    } else {
      // V1 uses GET (The Fix from your Python script)
      const res = await fetch(API.v1.create, { 
        method: "GET", // <--- CHANGED FROM POST
        headers: {
           "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ChromeExtension"
        }
      });
      
      // Catch HTML errors (like 404/500)
      if (!res.ok) {
         const errText = await res.text();
         throw new Error(`v1 failed status ${res.status}. Server returned HTML, not JSON.`);
      }
      
      const data = await res.json();
      // Handle different response structures just in case
      if (!data.address || !data.token) {
        throw new Error("v1 response missing address or token");
      }
      return { address: data.address, token: data.token, apiVersion: "v1" };
    }
  } catch (err) {
    throw new Error(
      `Could not create temp inbox (${err.message}). ` +
      `If tempmail.lol requires an API key, add it in the extension popup settings.`
    );
  }
}

async function fetchInboxMessages(token, apiVersion) {
  const settings = await getSettings();
  const headers = {};
  if (apiVersion === "v2") headers["X-API-Token"] = settings.apiToken;

  const url = apiVersion === "v2" ? API.v2.inbox(token) : API.v1.inbox(token);
  const res = await fetch(url, { headers });
  if (!res.ok) throw new Error(`inbox fetch failed: ${res.status}`);
  const data = await res.json();
  const list = [data.email, data.emails, data.messages].find(Array.isArray);
  if (!list) throw new Error(`unexpected inbox response: ${JSON.stringify(data).slice(0, 120)}`);
  return list;
}

// ============ session management ============
async function getSessionForTab(tabId) {
  const key = `session_${tabId}`;
  const store = await chrome.storage.local.get(key);
  return store[key] || null;
}

async function saveSession(session) {
  await chrome.storage.local.set({ [`session_${session.tabId}`]: session });
}

async function addHistoryEntry(entry) {
  const { history } = await chrome.storage.local.get("history");
  const list = history || [];
  list.push(entry);
  await chrome.storage.local.set({ history: list });
}

async function markSessionStatus(tabId, status) {
  const session = await getSessionForTab(tabId);
  if (!session) return;
  session.status = status;
  await saveSession(session);
  // update matching history entry
  const { history } = await chrome.storage.local.get("history");
  const list = history || [];
  for (let i = list.length - 1; i >= 0; i--) {
    if (list[i].id === session.id) {
      list[i].status = status;
      break;
    }
  }
  await chrome.storage.local.set({ history: list });
}

// ============ OTP polling ============
const lastPollAt = {}; // tabId -> ms; in-memory, a worker restart just resets it
const seenMessages = {}; // tabId -> count already logged, so each mail is previewed once

// what the last inbox check saw, so the popup can say whether polling is alive
// ============ verification links ============
// For sites that mail "click to confirm" instead of a code. The link text is the
// strongest signal ("Verify email"); the URL path is the fallback.
const LINK_TEXT = /verif|confirm|activat|validat|complete (your )?(registration|sign.?up)/i;
const LINK_URL = /verif|confirm|activat|validat/i;
const LINK_SKIP = /unsubscribe|opt.?out|privacy|terms|policy|preferences|support|help|mailto:|facebook|twitter|instagram|linkedin|youtube|\.(png|jpe?g|gif|svg)(\?|$)/i;

function linkFromMessage(msg) {
  const html = (msg.html || "").toString();
  const anchors = [...html.matchAll(/<a\b[^>]*?href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)]
    .map((m) => ({ url: m[1], text: stripHtml(m[2]).trim() }));
  const bare = [...(msg.body || "").toString().matchAll(/https?:\/\/[^\s"'<>)\]]+/g)]
    .map((m) => ({ url: m[0], text: "" }));

  const clean = (u) => u.trim().replace(/&amp;/g, "&");
  const usable = [...anchors, ...bare]
    .map((c) => ({ ...c, url: clean(c.url) }))
    .filter((c) => /^https?:\/\//i.test(c.url) && !LINK_SKIP.test(c.url) && !LINK_SKIP.test(c.text));

  return (usable.find((c) => LINK_TEXT.test(c.text)) || usable.find((c) => LINK_URL.test(c.url)))?.url || null;
}

// what the popup's inbox viewer shows - the last few mails, trimmed
function summarizeInbox(messages) {
  return messages.slice(-10).map((m) => ({
    from: m.from || "",
    subject: m.subject || "",
    date: m.date || null,
    text: ((m.body || "").trim() || stripHtml(m.html || "")).trim().slice(0, 2000),
    code: otpFromMessage(m),
    link: linkFromMessage(m),
  }));
}

async function recordCheck(tabId, token, check, inbox) {
  const session = await getSessionForTab(tabId);
  if (!session || session.inboxToken !== token) return null; // regenerated meanwhile
  session.lastCheck = check;
  if (inbox) session.inbox = inbox;
  await saveSession(session);
  return session;
}

async function pollTabInbox(tabId, via = "?") {
  const { otpPolls } = await chrome.storage.local.get("otpPolls");
  const poll = (otpPolls || {})[String(tabId)];
  if (!poll) {
    dlog("bg", `poll (${via}) tab ${tabId}: no active poll, skipped`);
    return;
  }

  if (Date.now() - poll.startedAt > OTP_POLL_TOTAL_MS) {
    dlog("bg", `poll tab ${tabId}: 12 min limit reached, giving up`, { inbox: tok(poll.token) });
    await stopPolling(tabId, "timeout");
    await markSessionStatus(tabId, "timeout");
    chrome.action.setBadgeText({ text: "", tabId });
    chrome.tabs.sendMessage(tabId, { type: "OTP_TIMEOUT" }).catch(() => {});
    return;
  }

  if (!(await isEnabled())) {
    dlog("bg", `poll (${via}) tab ${tabId}: paused, extension is off`);
    return;
  }

  // burst timers and alarms can land close together; skip rather than eat a 429
  if (Date.now() - (lastPollAt[tabId] || 0) < POLL_MIN_GAP_MS) {
    dlog("bg", `poll (${via}) tab ${tabId}: skipped, checked <4s ago`);
    return;
  }
  lastPollAt[tabId] = Date.now();

  let messages;
  try {
    messages = await fetchInboxMessages(poll.token, poll.apiVersion);
  } catch (err) {
    dlog("bg", `poll (${via}) tab ${tabId}: FAILED ${err.message}`, { inbox: tok(poll.token) });
    await recordCheck(tabId, poll.token, { at: Date.now(), ok: false, error: err.message });
    return;
  }

  const session = await recordCheck(tabId, poll.token, {
    at: Date.now(),
    ok: true,
    count: messages.length,
    subjects: messages.slice(-3).map((m) => m.subject || "(no subject)"),
  }, summarizeInbox(messages));

  const secs = Math.round((Date.now() - poll.startedAt) / 1000);
  dlog("bg", `poll (${via}) tab ${tabId}: ${messages.length} email(s) at +${secs}s`, { inbox: tok(poll.token) });

  // preview every new mail once - shows what arrived and why no code was taken
  messages.slice(seenMessages[tabId] || 0).forEach((m) => {
    const text = ((m.body || "").trim() || stripHtml(m.html || "")).trim();
    dlog("bg", "  new email", {
      from: m.from, to: m.to, subject: m.subject,
      hasBody: !!(m.body || "").trim(), hasHtml: !!(m.html || "").trim(),
      preview: text.slice(0, 300),
      code: otpFromMessage(m),
      link: linkFromMessage(m),
    });
  });
  seenMessages[tabId] = messages.length;

  // a link doesn't end polling: welcome mails carry tracking links too, and a
  // wrong guess must not stop the wait for a code that's still on its way
  if (session && !session.verifyLink) {
    const link = messages.map(linkFromMessage).find(Boolean);
    if (link) await handleVerifyLink(tabId, session, link);
  }

  for (const msg of messages) {
    const otp = otpFromMessage(msg);
    if (otp) {
      dlog("bg", `OTP FOUND tab ${tabId}: ${otp}`, { subject: msg.subject });
      await stopPolling(tabId, "otp found");
      const session = await getSessionForTab(tabId);
      if (session) {
        session.otp = otp;
        await saveSession(session);
      }
      await markSessionStatus(tabId, "verified");

      let copied = false;
      if ((await getSettings()).copyOtp) {
        try {
          await copyToClipboard(otp);
          copied = true;
          dlog("bg", `OTP copied to clipboard`);
        } catch (e) {
          dlog("bg", `OTP could NOT be copied to clipboard: ${e.message}`);
        }
      }

      chrome.tabs.sendMessage(tabId, { type: "OTP_FOUND", otp, copied })
        .then(() => dlog("bg", `OTP delivered to page (tab ${tabId})`))
        .catch((e) => dlog("bg", `OTP could NOT be sent to page (tab ${tabId}): ${e.message}`));
      chrome.action.setBadgeText({ text: "✓", tabId });
      chrome.action.setBadgeBackgroundColor({ color: "#16a34a", tabId });
      return;
    }
  }
}

async function handleVerifyLink(tabId, session, link) {
  session.verifyLink = link;
  await saveSession(session);
  dlog("bg", `verification link found tab ${tabId}`, { link });
  chrome.action.setBadgeText({ text: "↗", tabId });
  chrome.action.setBadgeBackgroundColor({ color: "#16a34a", tabId });

  const settings = await getSettings();
  if (!settings.autoOpenLink) return;
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  await chrome.tabs.create({ url: link, openerTabId: tab?.id, index: tab ? tab.index + 1 : undefined });
  session.linkOpened = true;
  await saveSession(session);
  dlog("bg", "  opened it in a new tab (auto-open is on)");
}

function createPollAlarm(tabId) {
  // first tick lands after the startup burst (0-25s)
  return chrome.alarms.create(`otp-${tabId}`, {
    delayInMinutes: 0.5,
    periodInMinutes: OTP_ALARM_PERIOD_MIN,
  });
}

async function startPolling(tabId, via = "?") {
  const session = await getSessionForTab(tabId);
  if (!session) {
    dlog("bg", `startPolling (${via}) tab ${tabId}: no session, nothing to poll`);
    return;
  }

  const { otpPolls } = await chrome.storage.local.get("otpPolls");
  const polls = otpPolls || {};
  if (polls[String(tabId)]?.token === session.inboxToken) {
    // already watching - but an extension reload drops alarms while the storage
    // entry survives, which used to leave the inbox silently unchecked
    const alive = !!(await chrome.alarms.get(`otp-${tabId}`));
    if (!alive) await createPollAlarm(tabId);
    dlog("bg", `startPolling (${via}) tab ${tabId}: already watching ${session.address}` + (alive ? "" : " - alarm was missing, re-armed"));
    return;
  }

  polls[String(tabId)] = {
    token: session.inboxToken,
    apiVersion: session.apiVersion,
    startedAt: Date.now(),
  };
  await chrome.storage.local.set({ otpPolls: polls });

  // Periodic safety-net polling
  await createPollAlarm(tabId);
  seenMessages[tabId] = 0;
  dlog("bg", `startPolling (${via}) tab ${tabId}: now watching ${session.address}`, { inbox: tok(session.inboxToken), api: session.apiVersion });

  // Immediate burst: OTPs often arrive within seconds
  for (let i = 0; i < 6; i++) {
    setTimeout(() => pollTabInbox(tabId, "burst"), i * 5000);
  }
}

async function stopPolling(tabId, reason = "?") {
  dlog("bg", `stopPolling tab ${tabId}: ${reason}`);
  await chrome.alarms.clear(`otp-${tabId}`);
  delete lastPollAt[tabId];
  const { otpPolls } = await chrome.storage.local.get("otpPolls");
  const polls = otpPolls || {};
  delete polls[String(tabId)];
  await chrome.storage.local.set({ otpPolls: polls });
}

// runs on every service-worker start (reload, update, browser restart)
(async () => {
  const { otpPolls } = await chrome.storage.local.get("otpPolls");
  const rearmed = [];
  for (const tabId of Object.keys(otpPolls || {})) {
    if (!(await chrome.alarms.get(`otp-${tabId}`))) {
      await createPollAlarm(Number(tabId));
      rearmed.push(tabId);
    }
  }
  dlog("bg", "service worker started", { activePolls: Object.keys(otpPolls || {}), rearmed, enabled: await isEnabled() });
  syncPower();
})();

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name.startsWith("otp-")) {
    const tabId = Number(alarm.name.slice(4));
    pollTabInbox(tabId, "alarm");
  }
});

// ============ session creation ============
async function createSession(tabId, url) {
  const inbox = await createInbox();
  const session = {
    id: crypto.randomUUID(),
    tabId,
    url,
    address: inbox.address,
    inboxToken: inbox.token,
    apiVersion: inbox.apiVersion,
    password: generatePassword(),
    createdAt: Date.now(),
    status: "pending",
  };
  await saveSession(session);
  await addHistoryEntry({
    id: session.id,
    address: session.address,
    password: session.password,
    url,
    createdAt: session.createdAt,
    status: "pending",
  });

  dlog("bg", `new inbox for tab ${tabId}: ${session.address}`, { inbox: tok(session.inboxToken), api: session.apiVersion, url });
  chrome.action.setBadgeText({ text: "●", tabId });
  chrome.action.setBadgeBackgroundColor({ color: "#2563eb", tabId });

  // start watching the inbox straight away - waiting for an OTP page to be
  // detected first meant same-page and oddly-named OTP flows never polled
  await startPolling(tabId, "new inbox");
  return session;
}

// ============ regenerate + fill ============
// Shared by the popup's Generate button and the keyboard shortcut.
async function regenerateForTab(tabId, url, via) {
  dlog("bg", `REGENERATE (${via}) tab ${tabId}`, { url });
  if (!(await isEnabled())) throw new Error(OFF_MSG);
  await stopPolling(tabId, "regenerate - old inbox abandoned");
  const session = await createSession(tabId, url);
  const fill = await chrome.tabs
    .sendMessage(tabId, { type: "FILL", address: session.address, password: session.password })
    .catch(() => null); // no content script on this page (chrome://, or opened before install)
  dlog("bg", "  page fill result", { filled: fill?.filled ?? "no content script on page" });
  return { session, filled: fill?.filled ?? null };
}

// ============ clipboard (offscreen document) ============
// An MV3 service worker has no DOM, so it can't touch the clipboard. A hidden
// offscreen page does the copy; it's opened per copy and closed straight after.
let clipboardChain = Promise.resolve();
function copyToClipboard(text) {
  const run = async () => {
    // Firefox has no offscreen documents, but its background is a page with a DOM
    // that may write to the clipboard directly (clipboardWrite permission)
    if (!chrome.offscreen) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const open = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    if (!open.length) {
      await chrome.offscreen.createDocument({
        url: "offscreen/offscreen.html",
        reasons: ["CLIPBOARD"],
        justification: "Copy the verification code to the clipboard",
      });
    }
    const res = await chrome.runtime.sendMessage({ target: "offscreen", type: "COPY", text });
    await chrome.offscreen.closeDocument().catch(() => {});
    if (!res?.ok) throw new Error("copy command was rejected");
  };
  // one at a time - only a single offscreen document may exist
  const job = clipboardChain.then(run);
  clipboardChain = job.catch(() => {});
  return job;
}

// ============ message routing ============
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    const tabId = sender.tab?.id;

    if (msg.type === "LOG") {
      dlog(`page:${tabId}`, msg.msg, msg.data);
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "GENERATE") {
      try {
        const settings = await getSettings();
        dlog("bg", `GENERATE from tab ${tabId}`, { url: msg.url });
        if (!(await isEnabled())) {
          dlog("bg", "  refused: extension is off");
          sendResponse({ ok: false, error: "extension is off" });
          return;
        }
        if (!settings.autoGenerate) {
          dlog("bg", "  refused: auto-generate is off");
          sendResponse({ ok: false, error: "auto-generate disabled" });
          return;
        }

        // reuse the session while this signup is in progress: a reload, an SPA
        // step, or /signup -> /signup/verify must not swap in a new inbox, or the
        // OTP lands in the old one while we poll the new one
        const existing = await getSessionForTab(tabId);
        if (
          existing &&
          Date.now() - existing.createdAt < SESSION_TTL_MS &&
          (existing.url === msg.url || (existing.status === "pending" && sameSite(existing.url, msg.url)))
        ) {
          dlog("bg", `  reusing ${existing.address}`, { status: existing.status, sameUrl: existing.url === msg.url });
          sendResponse({ ok: true, reused: true, address: existing.address, password: existing.password });
          return;
        }

        if (existing) {
          dlog("bg", `  NOT reusing ${existing.address}`, {
            ageSec: Math.round((Date.now() - existing.createdAt) / 1000),
            status: existing.status, oldUrl: existing.url,
          });
        }
        const session = await createSession(tabId, msg.url);

        sendResponse({ ok: true, reused: false, address: session.address, password: session.password });
      } catch (err) {
        dlog("bg", `  GENERATE failed: ${err.message}`);
        sendResponse({ ok: false, error: err.message });
      }
      return;
    }

    if (msg.type === "REGENERATE" && msg.tabId) {
      // sent from the popup, so there's no sender.tab - the popup names the tab
      try {
        const { session, filled } = await regenerateForTab(msg.tabId, msg.url, "popup button");
        sendResponse({ ok: true, session, filled });
      } catch (err) {
        dlog("bg", `  REGENERATE failed: ${err.message}`);
        sendResponse({ ok: false, error: err.message });
      }
      return;
    }

    if (msg.type === "CHECK_NOW" && msg.tabId) {
      // from the popup: revive a dead or timed-out poll and check right away
      const session = await getSessionForTab(msg.tabId);
      dlog("bg", `CHECK NOW (popup) tab ${msg.tabId}`, { address: session?.address, status: session?.status });
      if (!(await isEnabled())) {
        dlog("bg", "  skipped: extension is off");
      } else if (session && session.status !== "verified") {
        if (session.status === "timeout") await markSessionStatus(msg.tabId, "pending");
        await startPolling(msg.tabId, "check now");
        await pollTabInbox(msg.tabId, "check now"); // still honours POLL_MIN_GAP_MS
      }
      sendResponse({ ok: true, session: await getSessionForTab(msg.tabId) });
      return;
    }

    if (msg.type === "POLL_START" && tabId) {
      await startPolling(tabId, "page saw OTP field");
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "GET_SESSION" && tabId) {
      const session = await getSessionForTab(tabId);
      sendResponse({ ok: true, session });
      return;
    }

    sendResponse({ ok: false, error: "unknown message" });
  })();

  return true; // async sendResponse
});

// ============ power state ============
// Hide the right-click menu and show "off" on the toolbar while switched off.
// Tab badges beat the global one, so every tab with a session is repainted.
async function syncPower() {
  const on = await isEnabled();
  chrome.contextMenus.update("tempfill", { visible: on }, () => void chrome.runtime.lastError);
  chrome.action.setBadgeText({ text: on ? "" : "off" });
  chrome.action.setBadgeBackgroundColor({ color: "#71717a" });

  const all = await chrome.storage.local.get(null);
  for (const [key, s] of Object.entries(all)) {
    if (!key.startsWith("session_") || !s?.tabId) continue;
    const [text, color] = !on ? ["off", "#71717a"]
      : s.status === "verified" ? ["✓", "#16a34a"]
      : s.verifyLink ? ["↗", "#16a34a"]
      : s.status === "pending" ? ["●", "#2563eb"]
      : ["", "#71717a"];
    chrome.action.setBadgeText({ text, tabId: s.tabId }).catch(() => {}); // tab may be gone
    chrome.action.setBadgeBackgroundColor({ color, tabId: s.tabId }).catch(() => {});
  }
  return on;
}

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== "local" || !changes.enabled) return;
  const on = await syncPower();
  dlog("bg", `power ${on ? "ON" : "OFF"} (from popup)` + (on ? " - paused inbox checks resume on the next tick" : " - inbox checks paused"));
});

// ============ keyboard shortcut ============
// "generate-fill" in manifest.json (Alt+Shift+E by default; rebind at
// chrome://extensions/shortcuts). Same as the popup's Generate button.
chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== "generate-fill") return;
  const target = tab?.id ? tab : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!target?.id) return;
  try {
    await regenerateForTab(target.id, target.url, "keyboard shortcut");
  } catch (err) {
    dlog("bg", `  shortcut generate failed: ${err.message}`);
    chrome.tabs.sendMessage(target.id, { type: "TOAST", text: `Temp email failed: ${err.message}`, level: "error" }).catch(() => {});
  }
});

// ============ right-click fill ============
// Fallback for pages the heuristics miss: fill whatever field was right-clicked.
const MENU = { "fill-email": "email", "fill-password": "password", "fill-otp": "otp" };

chrome.runtime.onInstalled.addListener(({ reason }) => {
  // a fresh install starts switched OFF - nothing is filled until the user turns it
  // on from the popup; updates and reloads keep whatever the user chose
  if (reason === "install") {
    chrome.storage.local.set({ enabled: false });
    chrome.tabs.create({ url: chrome.runtime.getURL("docs/docs.html") });
  }

  chrome.contextMenus.removeAll(() => {
    const menu = (id, title, parentId) =>
      chrome.contextMenus.create({ id, title, parentId, contexts: ["editable"] });
    menu("tempfill", "BurnerFill");
    menu("fill-email", "Fill temp email", "tempfill");
    menu("fill-password", "Fill password", "tempfill");
    menu("fill-otp", "Fill OTP code", "tempfill");
    syncPower();
  });
});

// the signup already under way on this site, or a fresh one - same rule as GENERATE
async function sessionForFill(tabId, url) {
  const existing = await getSessionForTab(tabId);
  if (existing && existing.status === "pending" && sameSite(existing.url, url)) return existing;
  return createSession(tabId, url);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const kind = MENU[info.menuItemId];
  if (!kind || !tab?.id) return;
  // toasts go to the top frame - the content script doesn't run inside iframes
  const toast = (text, level = "info") =>
    chrome.tabs.sendMessage(tab.id, { type: "TOAST", text, level }, { frameId: 0 }).catch(() => {});
  dlog("bg", `right-click fill: ${kind} (tab ${tab.id}, frame ${info.frameId})`);
  if (!(await isEnabled())) { // the menu is hidden while off; this covers a stale one
    toast(OFF_MSG, "warning");
    return;
  }

  try {
    let session;
    let value;
    if (kind === "otp") {
      session = await getSessionForTab(tab.id);
      if (!session?.otp) {
        toast(session?.status === "pending" ? "No code yet — still checking the inbox" : "No OTP code for this tab", "warning");
        return;
      }
      value = session.otp;
    } else {
      session = await sessionForFill(tab.id, info.pageUrl || tab.url);
      value = kind === "email" ? session.address : session.password;
    }
    await chrome.tabs.sendMessage(
      tab.id,
      { type: "FILL_FIELD", kind, value, address: session.address, password: session.password },
      { frameId: info.frameId ?? 0 }
    );
  } catch (err) {
    dlog("bg", `  right-click fill failed: ${err.message}`);
    toast(info.frameId ? "Can't fill fields inside embedded frames" : `Couldn't fill: ${err.message}`, "error");
  }
});

// clean up polling + sessions for closed tabs
chrome.tabs.onRemoved.addListener(async (tabId) => {
  await stopPolling(tabId, "tab closed");
  await chrome.storage.local.remove(`session_${tabId}`);
});
