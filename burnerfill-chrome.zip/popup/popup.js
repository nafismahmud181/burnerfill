const DEFAULTS = {
  autoGenerate: true, fillEmail: true, fillPassword: true,
  fillConfirmPassword: true, autoSubmitOtp: false, autoOpenLink: false, copyOtp: true, apiToken: "",
};
const SETTING_IDS = Object.keys(DEFAULTS);

const el = (id) => document.getElementById(id);

const make = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
};

async function loadAll() {
  const { settings, history } = await chrome.storage.local.get(["settings", "history"]);
  const s = { ...DEFAULTS, ...(settings || {}) };
  SETTING_IDS.forEach((k) => { if (typeof s[k] === "boolean") el(k).checked = s[k]; });
  el("apiToken").value = s.apiToken || "";
  renderHistory(history || []);
  await renderSession();
}

function credRow(label, value) {
  const row = make("div", "cred");
  const text = make("div", "cred-text");
  text.append(make("span", "cred-label", label), make("span", "cred-value", value));

  const btn = make("button", "copy", "Copy");
  btn.type = "button";
  btn.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(value); btn.textContent = "Copied"; }
    catch { btn.textContent = "Failed"; }
    setTimeout(() => (btn.textContent = "Copy"), 1200);
  });

  row.append(text, btn);
  return row;
}

const ago = (at) => {
  const sec = Math.max(0, Math.round((Date.now() - at) / 1000));
  if (sec < 5) return "just now";
  if (sec < 60) return `${sec}s ago`;
  return `${Math.floor(sec / 60)}m ago`;
};

// "Checked 12s ago" etc; the ticker below keeps [data-at] spans current
const agoSpan = (at) => {
  const span = make("span", null, ago(at));
  span.dataset.at = at;
  return span;
};

function checkLine(session, polling, tabId) {
  const line = make("div", "s-check");
  const text = make("div", "s-check-text");
  const c = session.lastCheck;

  if (session.status === "timeout") {
    text.append("Stopped after 12 min with no code.");
  } else if (!polling) {
    text.append("Inbox is not being checked.");
  } else if (!c) {
    text.append("Checking inbox…");
  } else if (!c.ok) {
    line.classList.add("error");
    text.append("Last check failed ", agoSpan(c.at), `: ${c.error}`);
  } else {
    text.append("Checked ", agoSpan(c.at), ` · ${c.count} email${c.count === 1 ? "" : "s"}`);
    if (c.count && !session.inbox?.length) { // the inbox list below says it better
      text.append(make("div", "s-subjects", "No code found in: " + c.subjects.map((x) => `“${x}”`).join(", ")));
    }
  }

  const btn = make("button", "tiny", "Check now");
  btn.type = "button";
  btn.addEventListener("click", async () => {
    btn.disabled = true;
    btn.textContent = "Checking…";
    await chrome.runtime.sendMessage({ type: "CHECK_NOW", tabId }).catch(() => {});
    await renderSession();
  });

  line.append(text, btn);
  return line;
}

// a verification link, opened in a new tab; the host is shown so you know where it goes
function linkButton(url, label, cls = "link-btn") {
  const btn = make("button", cls, label);
  btn.type = "button";
  btn.title = url;
  try { btn.append(make("span", "link-host", new URL(url).hostname)); } catch { /* keep label only */ }
  btn.addEventListener("click", () => chrome.tabs.create({ url }));
  return btn;
}

function mailTime(d) {
  if (!d) return "";
  const t = typeof d === "number" ? (d < 1e12 ? d * 1000 : d) : Date.parse(d);
  return Number.isFinite(t) ? new Date(t).toLocaleTimeString() : "";
}

// rows stay open across the re-render every poll triggers
const openMail = new Set();

function inboxList(inbox) {
  const wrap = make("div", "inbox");
  wrap.append(make("div", "inbox-head", `Inbox · ${inbox.length}`));

  inbox.map((m, i) => ({ m, key: `${i}|${m.subject}|${m.date}` })).reverse().forEach(({ m, key }) => {
    const row = make("details", "mail");
    row.open = openMail.has(key);
    row.addEventListener("toggle", () => (row.open ? openMail.add(key) : openMail.delete(key)));

    const summary = make("summary");
    const top = make("span", "mail-top");
    top.append(make("span", "mail-from", m.from || "(unknown sender)"), make("span", "mail-time", mailTime(m.date)));
    summary.append(top, make("span", "mail-subject", m.subject || "(no subject)"));
    if (m.code) summary.append(make("span", "mail-tag code", `code ${m.code}`));
    else if (m.link) summary.append(make("span", "mail-tag link", "verification link"));

    row.append(summary, make("div", "mail-body", m.text || "(empty message)"));
    if (m.link) row.append(linkButton(m.link, "Open link", "link-btn small"));
    wrap.append(row);
  });
  return wrap;
}

let currentTabId = null;

async function renderSession() {
  const box = el("currentSession");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    currentTabId = tab.id;
    const key = `session_${tab.id}`;
    const { [key]: session, otpPolls } = await chrome.storage.local.get([key, "otpPolls"]);
    if (!session) {
      box.classList.remove("has-session");
      box.textContent = "No active session on this tab.";
      return;
    }

    const polling = !!(otpPolls || {})[String(tab.id)];
    const verified = session.status === "verified";
    const stopped = session.status === "timeout" || (!verified && !polling);
    const label = verified ? "Verified" : session.status === "timeout" ? "Timed out"
      : polling ? "Waiting for OTP" : "Not checking";

    const head = make("div", "s-head");
    head.append(
      make("span", "s-status" + (verified ? " verified" : stopped ? " stopped" : ""), label),
      make("span", "s-time", "Started " + new Date(session.createdAt).toLocaleTimeString())
    );

    const parts = [head, credRow("Email", session.address), credRow("Password", session.password)];
    if (session.otp) parts.push(credRow("OTP code", session.otp));
    if (session.verifyLink) parts.push(linkButton(session.verifyLink, session.linkOpened ? "Open verification link again" : "Open verification link"));
    if (!verified) parts.push(checkLine(session, polling, tab.id));
    if (session.inbox?.length) parts.push(inboxList(session.inbox));

    box.classList.add("has-session");
    box.replaceChildren(...parts);
  } catch {
    box.classList.remove("has-session");
    box.textContent = "-";
  }
}

function renderHistory(list) {
  const box = el("history");
  el("historyCount").textContent = list.length ? String(list.length) : "";
  if (!list.length) {
    box.textContent = "No accounts yet.";
    return;
  }

  box.replaceChildren(...[...list].reverse().map((e) => {
    const entry = make("div", "entry");
    entry.append(
      make("span", `badge ${e.status}`, e.status),
      make("b", null, e.address),
      document.createElement("br"),
      document.createTextNode(`pass: ${e.password}`)
    );
    return entry;
  }));
}

// the header pill is outside the settings form, so it saves on the spot
el("autoGenerate").addEventListener("change", async () => {
  const { settings } = await chrome.storage.local.get("settings");
  await chrome.storage.local.set({
    settings: { ...DEFAULTS, ...(settings || {}), autoGenerate: el("autoGenerate").checked },
  });
});

el("regenerate").addEventListener("click", async () => {
  const btn = el("regenerate");
  const note = el("regenNote");
  const label = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Generating…";
  note.textContent = "";
  note.classList.remove("error");

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("No active tab.");
    const res = await chrome.runtime.sendMessage({ type: "REGENERATE", tabId: tab.id, url: tab.url });
    if (!res?.ok) throw new Error(res?.error || "Could not generate a new email.");

    await renderSession();
    const { history } = await chrome.storage.local.get("history");
    renderHistory(history || []);

    if (res.filled === null) note.textContent = "Generated. Reload the page to fill it in there.";
    else if (res.filled.length) note.textContent = `Filled ${res.filled.join(", ")} on the page.`;
    else note.textContent = "Generated. No email or password fields found on this page.";
  } catch (err) {
    note.textContent = err.message;
    note.classList.add("error");
  } finally {
    btn.disabled = false;
    btn.textContent = label;
  }
});

el("saveSettings").addEventListener("click", async () => {
  const settings = { apiToken: el("apiToken").value.trim() };
  SETTING_IDS.filter((k) => k !== "apiToken").forEach((k) => { settings[k] = el(k).checked; });
  await chrome.storage.local.set({ settings });
  el("saveMsg").textContent = "Saved ✓";
  setTimeout(() => (el("saveMsg").textContent = ""), 1500);
});

el("clearHistory").addEventListener("click", async () => {
  await chrome.storage.local.set({ history: [] });
  renderHistory([]);
});

el("exportCsv").addEventListener("click", async () => {
  const { history } = await chrome.storage.local.get("history");
  const list = history || [];
  if (!list.length) return;
  const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const csv = [
    "address,password,url,created_at,status",
    ...list.map((e) =>
      [e.address, e.password, e.url, new Date(e.createdAt).toISOString(), e.status].map(esc).join(",")
    ),
  ].join("\n");

  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  a.download = "temp-accounts.csv";
  a.click();
  URL.revokeObjectURL(a.href);
});

// ============ user guide ============
// docs.html ships inside the extension - no hosting; reuse its tab if it's open
el("openDocs").addEventListener("click", async () => {
  const url = chrome.runtime.getURL("docs/docs.html");
  const open = (await chrome.tabs.query({})).find((t) => t.url?.startsWith(url));
  if (open) {
    await chrome.tabs.update(open.id, { active: true });
    await chrome.windows.update(open.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
  window.close();
});

// ============ keyboard shortcut ============
// shows the binding the user actually has, which may differ from the suggested one
chrome.commands.getAll().then((cmds) => {
  const key = cmds.find((c) => c.name === "generate-fill")?.shortcut;
  el("shortcutKey").textContent = key || "not set";
});
// Firefox blocks extensions from opening about:addons, so there it gets directions instead
const IS_FIREFOX = chrome.runtime.getURL("").startsWith("moz-extension:");
el("editShortcut").addEventListener("click", (e) => {
  e.preventDefault();
  if (IS_FIREFOX) {
    const note = el("regenNote");
    note.classList.remove("error");
    note.textContent = "In Firefox: open about:addons, click the ⚙ gear, then “Manage Extension Shortcuts”.";
    return;
  }
  chrome.tabs.create({ url: "chrome://extensions/shortcuts" }); // Edge redirects this to edge://
});

// ============ debug tab ============
const pad = (n, w = 2) => String(n).padStart(w, "0");
const stamp = (t) => {
  const d = new Date(t);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`;
};
const logLine = (e) =>
  `${stamp(e.t)} ${e.src.padEnd(9)} ${e.msg}` + (e.data !== undefined ? "  " + JSON.stringify(e.data) : "");

function renderDebug(list) {
  const box = el("debugLog");
  if (!list.length) { box.textContent = "No log entries yet."; return; }
  const stick = box.scrollTop + box.clientHeight >= box.scrollHeight - 20;
  box.replaceChildren(...list.map((e) => {
    const row = make("div");
    const bad = /FAIL|WARNING|NOT |could NOT|refused|no session|no active poll|timeout|12 min/.test(e.msg);
    const good = /OTP FOUND|OTP filled|OTP delivered|matchesOurs":true|"match":true/.test(e.msg + JSON.stringify(e.data ?? ""));
    row.append(
      make("span", "t", stamp(e.t) + " "),
      make("span", e.src === "bg" ? "bg" : "pg", e.src.padEnd(9) + " "),
      make("span", bad ? "warn" : good ? "ok" : null, e.msg),
    );
    if (e.data !== undefined) row.append(make("span", "d", "  " + JSON.stringify(e.data)));
    return row;
  }));
  if (stick) box.scrollTop = box.scrollHeight;
}

el("copyLog").addEventListener("click", async () => {
  const { debugLog } = await chrome.storage.local.get("debugLog");
  const list = debugLog || [];
  const header = [
    `BurnerFill ${chrome.runtime.getManifest().version} debug log`,
    `copied ${new Date().toString()}`,
    `${navigator.userAgent}`,
    `${list.length} entries`,
    "",
  ];
  const btn = el("copyLog");
  try {
    await navigator.clipboard.writeText(header.concat(list.map(logLine)).join("\n"));
    btn.textContent = "Copied";
  } catch { btn.textContent = "Copy failed"; }
  setTimeout(() => (btn.textContent = "Copy log"), 1500);
});

el("clearLog").addEventListener("click", async () => {
  await chrome.storage.local.set({ debugLog: [] });
  renderDebug([]);
});

// hidden from normal use - shift+click the logo to open it
document.querySelector(".logo").addEventListener("click", (e) => {
  if (!e.shiftKey) return;
  document.body.classList.add("show-debug");
  el("tab-debug").checked = true;
});

chrome.storage.local.get("debugLog").then(({ debugLog }) => {
  renderDebug(debugLog || []);
  el("debugLog").scrollTop = el("debugLog").scrollHeight;
});

// polls write to storage in the background; mirror them while the popup is open
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[`session_${currentTabId}`] || changes.otpPolls) renderSession();
  if (changes.history) renderHistory(changes.history.newValue || []);
  if (changes.debugLog) renderDebug(changes.debugLog.newValue || []);
});

setInterval(() => {
  document.querySelectorAll("[data-at]").forEach((n) => (n.textContent = ago(Number(n.dataset.at))));
}, 1000);

loadAll();

// ============ power button + off screen ============
// stored as top-level keys (not inside "settings") so Save settings never overwrites them.
// background/content scripts should skip all work while storage "enabled" === false.
const POWER_DEFAULTS = { enabled: true, offStyle: "blackout" };
const OFF_STYLES = ["blackout", "switch", "shutter"];
const offBlackout = document.querySelector(".off-blackout");
const offSwitch = document.querySelector(".off-switch");
let holdTimer = null;
let flipTimer = null;
let poweringTimer = null;

function applyOffStyle(style) {
  const s = OFF_STYLES.includes(style) ? style : POWER_DEFAULTS.offStyle;
  document.body.dataset.offStyle = s;
  document.querySelectorAll('input[name="offStyle"]').forEach((r) => (r.checked = r.value === s));
}

function applyPower(enabled) {
  const body = document.body;
  clearTimeout(holdTimer);
  offBlackout.classList.remove("holding");
  if (enabled) {
    // keep the tall min-height while the off screen animates away
    body.classList.add("powering");
    clearTimeout(poweringTimer);
    poweringTimer = setTimeout(() => body.classList.remove("powering"), 700);
    body.classList.remove("is-off");
  } else {
    clearTimeout(flipTimer);
    offSwitch.classList.remove("flipped");
    body.classList.add("is-off");
    const focusId = { blackout: "holdBtn", switch: "switchBtn", shutter: "shutterBtn" }[body.dataset.offStyle];
    setTimeout(() => el(focusId)?.focus({ preventScroll: true }), 50);
  }
}

async function setEnabled(enabled) {
  applyPower(enabled);
  await chrome.storage.local.set({ enabled });
}

el("powerBtn").addEventListener("click", () => setEnabled(false));
el("previewOff").addEventListener("click", () => setEnabled(false));

document.querySelectorAll('input[name="offStyle"]').forEach((r) =>
  r.addEventListener("change", async () => {
    if (!r.checked) return;
    applyOffStyle(r.value);
    await chrome.storage.local.set({ offStyle: r.value });
  })
);

// 2a blackout: press and hold for 0.9s
const holdStart = () => {
  if (offBlackout.classList.contains("holding")) return;
  offBlackout.classList.add("holding");
  holdTimer = setTimeout(() => setEnabled(true), 900);
};
const holdEnd = () => {
  clearTimeout(holdTimer);
  offBlackout.classList.remove("holding");
};
const holdBtn = el("holdBtn");
holdBtn.addEventListener("pointerdown", (e) => {
  // capture keeps pointerup coming here if the pointer drifts off the button;
  // it's a nicety, so a refusal must not stop the hold itself
  try { holdBtn.setPointerCapture(e.pointerId); } catch { /* hold works without it */ }
  holdStart();
});
["pointerup", "pointercancel", "lostpointercapture"].forEach((t) => holdBtn.addEventListener(t, holdEnd));
holdBtn.addEventListener("keydown", (e) => {
  if ((e.key === " " || e.key === "Enter") && !e.repeat) { e.preventDefault(); holdStart(); }
});
holdBtn.addEventListener("keyup", (e) => { if (e.key === " " || e.key === "Enter") holdEnd(); });
holdBtn.addEventListener("blur", holdEnd);

// 2b wall switch: flip, then reveal
el("switchBtn").addEventListener("click", () => {
  if (offSwitch.classList.contains("flipped")) return;
  offSwitch.classList.add("flipped");
  flipTimer = setTimeout(() => setEnabled(true), 550);
});

// 2c shutter: one press
el("shutterBtn").addEventListener("click", () => setEnabled(true));

// initial state without animation (popup opening while off shows the off screen straight away)
document.body.classList.add("no-anim");
chrome.storage.local.get(["enabled", "offStyle"]).then(({ enabled, offStyle }) => {
  applyOffStyle(offStyle);
  if (enabled === false) { document.body.classList.add("is-off"); } 
  requestAnimationFrame(() => requestAnimationFrame(() => document.body.classList.remove("no-anim")));
  if (enabled === false) {
    const focusId = { blackout: "holdBtn", switch: "switchBtn", shutter: "shutterBtn" }[document.body.dataset.offStyle];
    el(focusId)?.focus({ preventScroll: true });
  }
});

// stay in sync if toggled from elsewhere (another popup window, the background, a shortcut)
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.offStyle) applyOffStyle(changes.offStyle.newValue);
  if (changes.enabled) {
    const on = changes.enabled.newValue !== false;
    if (on === document.body.classList.contains("is-off")) applyPower(on);
  }
});
