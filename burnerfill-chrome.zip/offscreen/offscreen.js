// Clipboard helper for background.js. navigator.clipboard needs a focused page,
// which an offscreen document never is, so this uses the textarea + execCommand route.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== "offscreen" || msg.type !== "COPY") return;
  const box = document.getElementById("clip");
  box.value = msg.text;
  box.select();
  const ok = document.execCommand("copy");
  box.value = "";
  sendResponse({ ok });
});
